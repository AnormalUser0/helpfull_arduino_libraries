Copy the folders in the arduino libraries folder
This is normaly saved in your "Documents\Arduino\libraries" path
